import { faker } from '@faker-js/faker';
import { Alert } from '../store/slices/alertsSlice';

// Santo Domingo coordinates and districts
const santoDoringoDistricts = [
  { name: 'Distrito Nacional', lat: 18.4861, lng: -69.9312 },
  { name: 'Santo Domingo Norte', lat: 18.5144, lng: -69.8977 },
  { name: 'Santo Domingo Este', lat: 18.4888, lng: -69.8571 },
  { name: 'Santo Domingo Oeste', lat: 18.4701, lng: -70.0076 },
  { name: 'Los Alcarrizos', lat: 18.4984, lng: -70.0021 },
  { name: 'Pedro Brand', lat: 18.5644, lng: -70.0087 },
];

const alertTypes: Alert['type'][] = ['flood', 'collapse', 'incident', 'fire', 'earthquake'];
const severityLevels: Alert['severity'][] = ['critical', 'high', 'medium', 'low'];
const statusOptions: Alert['status'][] = ['active', 'resolved', 'investigating'];

export const generateMockAlerts = (count: number = 20): Alert[] => {
  const alerts: Alert[] = [];
  
  for (let i = 0; i < count; i++) {
    const district = faker.helpers.arrayElement(santoDoringoDistricts);
    const type = faker.helpers.arrayElement(alertTypes);
    const severity = faker.helpers.arrayElement(severityLevels);
    
    // Generate coordinates within district boundaries
    const lat = district.lat + (faker.number.float() - 0.5) * 0.05;
    const lng = district.lng + (faker.number.float() - 0.5) * 0.05;
    
    const alert: Alert = {
      id: faker.string.uuid(),
      type,
      severity,
      title: generateAlertTitle(type, severity),
      description: generateAlertDescription(type),
      location: {
        lat,
        lng,
        address: faker.location.streetAddress(),
        district: district.name,
      },
      timestamp: faker.date.recent({ days: 7 }),
      status: faker.helpers.arrayElement(statusOptions),
      affectedPopulation: severity === 'critical' ? faker.number.int({ min: 100, max: 5000 }) : undefined,
      estimatedDamage: severity === 'critical' || severity === 'high' ? 
        `$${faker.number.int({ min: 10000, max: 1000000 }).toLocaleString()}` : undefined,
    };
    
    alerts.push(alert);
  }
  
  return alerts.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
};

function generateAlertTitle(type: Alert['type'], severity: Alert['severity']): string {
  const titles = {
    flood: [
      `${severity === 'critical' ? 'Inundación severa' : 'Inundación'} reportada`,
      'Acumulación de agua en vía pública',
      'Desbordamiento de canal pluvial',
    ],
    collapse: [
      'Colapso estructural reportado',
      'Edificación en riesgo de colapso',
      'Daños estructurales detectados',
    ],
    incident: [
      'Incidente vial mayor',
      'Bloqueo de vía principal',
      'Accidente con múltiples vehículos',
    ],
    fire: [
      'Incendio estructural',
      'Incendio forestal reportado',
      'Emergencia por fuego',
    ],
    earthquake: [
      'Actividad sísmica detectada',
      'Temblor reportado por ciudadanos',
      'Sismo de magnitud considerable',
    ],
  };
  
  return faker.helpers.arrayElement(titles[type]);
}

function generateAlertDescription(type: Alert['type']): string {
  const descriptions = {
    flood: [
      'Acumulación significativa de agua debido a fuertes lluvias. Se recomienda evitar el área.',
      'Sistema de drenaje colapsado causando inundaciones en calles principales.',
      'Nivel del agua continúa subiendo. Unidades de emergencia en camino.',
    ],
    collapse: [
      'Estructura presenta signos visibles de deterioro. Área evacuada por seguridad.',
      'Grietas estructurales detectadas. Se ha acordonado el perímetro.',
      'Edificación antigua muestra signos de inestabilidad estructural.',
    ],
    incident: [
      'Accidente vehicular bloquea múltiples carriles. Tráfico desviado.',
      'Colisión múltiple causa congestión severa en área metropolitana.',
      'Incidente vial con heridos. Ambulancias y bomberos en escena.',
    ],
    fire: [
      'Incendio activo requiere intervención de bomberos. Humo visible.',
      'Fuego estructural controlado parcialmente. Evacuación preventiva.',
      'Emergencia por incendio en zona comercial. Vías cerradas.',
    ],
    earthquake: [
      'Temblor de tierra reportado por múltiples ciudadanos en el área.',
      'Actividad sísmica detectada por sensores. Sin daños mayores reportados.',
      'Sismo de intensidad moderada. Revisión de infraestructura en curso.',
    ],
  };
  
  return faker.helpers.arrayElement(descriptions[type]);
}

export const generateHeatmapData = () => {
  const data = [];
  
  for (let i = 0; i < 100; i++) {
    const district = faker.helpers.arrayElement(santoDoringoDistricts);
    const lat = district.lat + (faker.number.float() - 0.5) * 0.1;
    const lng = district.lng + (faker.number.float() - 0.5) * 0.1;
    
    data.push({
      lat,
      lng,
      intensity: faker.number.float({ min: 0.1, max: 1 }),
    });
  }
  
  return data;
};

export const generateHistoricalData = () => {
  const data = [];
  const types = ['flood', 'collapse', 'incident', 'fire', 'earthquake'];
  
  for (let i = 0; i < 30; i++) {
    const date = faker.date.past({ years: 1 });
    data.push({
      date: date.toISOString().split('T')[0],
      ...types.reduce((acc, type) => ({
        ...acc,
        [type]: faker.number.int({ min: 0, max: 10 }),
      }), {}),
      total: faker.number.int({ min: 5, max: 30 }),
    });
  }
  
  return data.sort((a, b) => a.date.localeCompare(b.date));
};