import React, { useState, useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '../hooks';
import { setAlerts } from '../store/slices/alertsSlice';
import { alertsApi } from '../api/alertsApi';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Calendar, Download, Filter, Play, Pause } from 'lucide-react';

export default function HistoricalView() {
  const [historicalData, setHistoricalData] = useState<any[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const dispatch = useAppDispatch();

  useEffect(() => {
    const loadHistoricalData = async () => {
      try {
        const data = await alertsApi.getHistoricalData();
        setHistoricalData(data);
      } catch (error) {
        console.error('Error loading historical data:', error);
      }
    };

    loadHistoricalData();
  }, []);

  const handleExportData = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Fecha,Inundaciones,Colapsos,Incidentes,Incendios,Sismos,Total\n"
      + historicalData.map(row => 
          `${row.date},${row.flood},${row.collapse},${row.incident},${row.fire},${row.earthquake},${row.total}`
        ).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "isaura_historical_data.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const togglePlayback = () => {
    setIsPlaying(!isPlaying);
    // This would control the timeline playback animation
  };

  return (
    <div className="h-full flex flex-col space-y-6 p-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">Análisis Histórico</h2>
            <p className="text-gray-600">
              Revisión de patrones y tendencias en los datos de incidentes del último año.
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleExportData}
              className="flex items-center space-x-2 px-4 py-2 bg-sky-600 text-white rounded-lg hover:bg-sky-700 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Exportar CSV</span>
            </button>
          </div>
        </div>
      </div>

      {/* Timeline Controls */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Control de Tiempo</h3>
          <div className="flex items-center space-x-3">
            <button
              onClick={togglePlayback}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                isPlaying ? 'bg-red-600 hover:bg-red-700 text-white' : 'bg-green-600 hover:bg-green-700 text-white'
              }`}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlaying ? 'Pausar' : 'Reproducir'}</span>
            </button>
          </div>
        </div>
        
        {/* Date Range Slider */}
        <div className="space-y-4">
          <div className="flex items-center space-x-4">
            <Calendar className="w-5 h-5 text-gray-500" />
            <span className="text-sm text-gray-600">Rango de fechas:</span>
            <input
              type="date"
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm"
              onChange={(e) => setSelectedDate(e.target.value)}
            />
            <span className="text-sm text-gray-600">a</span>
            <input
              type="date"
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm"
            />
          </div>
          
          {/* Timeline Slider */}
          <div className="relative">
            <input
              type="range"
              min="0"
              max={historicalData.length - 1}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-2">
              <span>Enero 2023</span>
              <span>Diciembre 2023</span>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Historical Trend Chart */}
        <div className="bg-white p-6 rounded-lg shadow-md xl:col-span-2">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Evolución Histórica de Incidentes
          </h3>
          <div style={{ width: '100%', height: 400 }}>
            <ResponsiveContainer>
              <BarChart data={historicalData.slice(-30)} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
                <YAxis stroke="#6b7280" fontSize={12} />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #e5e7eb',
                    borderRadius: '6px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                  }}
                />
                <Legend />
                <Bar dataKey="flood" stackId="a" fill="#3b82f6" name="Inundaciones" />
                <Bar dataKey="collapse" stackId="a" fill="#ef4444" name="Colapsos" />
                <Bar dataKey="incident" stackId="a" fill="#f59e0b" name="Incidentes" />
                <Bar dataKey="fire" stackId="a" fill="#f97316" name="Incendios" />
                <Bar dataKey="earthquake" stackId="a" fill="#8b5cf6" name="Sismos" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Resumen Anual</h3>
          <div className="space-y-3">
            {[
              { label: 'Total de incidentes', value: '2,847' },
              { label: 'Promedio mensual', value: '237' },
              { label: 'Mes más activo', value: 'Septiembre' },
              { label: 'Reducción vs año anterior', value: '-12%' },
            ].map((stat, index) => (
              <div key={index} className="flex justify-between">
                <span className="text-gray-600">{stat.label}:</span>
                <span className="font-semibold text-gray-900">{stat.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Distritos Afectados</h3>
          <div className="space-y-3">
            {[
              { district: 'Santo Domingo Norte', incidents: 847 },
              { district: 'Santo Domingo Este', incidents: 623 },
              { district: 'Distrito Nacional', incidents: 591 },
              { district: 'Santo Domingo Oeste', incidents: 432 },
            ].map((item, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-gray-600">{item.district}</span>
                <span className="font-semibold text-gray-900">{item.incidents}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Patrones Identificados</h3>
          <div className="space-y-3">
            <div className="p-3 bg-blue-50 rounded-lg border-l-4 border-blue-500">
              <div className="text-sm font-medium text-blue-900">Estacional</div>
              <div className="text-xs text-blue-700">Pico de inundaciones en Sep-Nov</div>
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg border-l-4 border-yellow-500">
              <div className="text-sm font-medium text-yellow-900">Horario</div>
              <div className="text-xs text-yellow-700">Más incidentes entre 7-9 AM</div>
            </div>
            <div className="p-3 bg-green-50 rounded-lg border-l-4 border-green-500">
              <div className="text-sm font-medium text-green-900">Mejora</div>
              <div className="text-xs text-green-700">Tiempo respuesta -15%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}