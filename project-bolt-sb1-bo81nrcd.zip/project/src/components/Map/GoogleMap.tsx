import React, { useEffect, useRef, useState } from 'react';
import { Loader } from '@googlemaps/js-api-loader';
import { useAppSelector, useAppDispatch } from '../../hooks';
import { setCenter, setZoom } from '../../store/slices/mapSlice';
import { selectAlert } from '../../store/slices/alertsSlice';
import { Alert } from '../../store/slices/alertsSlice';

const GOOGLE_MAPS_API_KEY = 'AIzaSyBxPxCHnZDfIQLz6c_LZtnSlIl0bqU_4YA';

interface GoogleMapProps {
  className?: string;
}

export default function GoogleMap({ className = '' }: GoogleMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const heatmapRef = useRef<google.maps.visualization.HeatmapLayer | null>(null);
  
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const { center, zoom, heatmapData, showHeatmap } = useAppSelector(state => state.map);
  const { filteredAlerts, selectedAlert } = useAppSelector(state => state.alerts);
  const dispatch = useAppDispatch();

  // Initialize Google Maps
  useEffect(() => {
    const loader = new Loader({
      apiKey: GOOGLE_MAPS_API_KEY,
      version: 'weekly',
      libraries: ['visualization'],
    });

    loader.load().then(() => {
      if (!mapRef.current) return;

      const map = new google.maps.Map(mapRef.current, {
        center,
        zoom,
        styles: [
          {
            featureType: 'poi',
            stylers: [{ visibility: 'off' }],
          },
          {
            featureType: 'transit',
            stylers: [{ visibility: 'off' }],
          },
        ],
        mapTypeControl: true,
        streetViewControl: false,
        fullscreenControl: true,
        zoomControl: true,
      });

      mapInstanceRef.current = map;
      
      // Add event listeners
      map.addListener('center_changed', () => {
        const newCenter = map.getCenter();
        if (newCenter) {
          dispatch(setCenter({
            lat: newCenter.lat(),
            lng: newCenter.lng(),
          }));
        }
      });

      map.addListener('zoom_changed', () => {
        dispatch(setZoom(map.getZoom() || 11));
      });

      setIsLoaded(true);
    }).catch((err) => {
      console.error('Error loading Google Maps:', err);
      setError('Error al cargar Google Maps');
    });
  }, []);

  // Update map center and zoom
  useEffect(() => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setCenter(center);
      mapInstanceRef.current.setZoom(zoom);
    }
  }, [center, zoom]);

  // Update markers
  useEffect(() => {
    if (!mapInstanceRef.current || !isLoaded) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    // Add new markers
    filteredAlerts.forEach(alert => {
      const marker = createMarker(alert, mapInstanceRef.current!);
      markersRef.current.push(marker);
      
      // Add click listener
      marker.addListener('click', () => {
        dispatch(selectAlert(alert));
      });
    });
  }, [filteredAlerts, isLoaded, dispatch]);

  // Update heatmap
  useEffect(() => {
    if (!mapInstanceRef.current || !isLoaded) return;

    // Remove existing heatmap
    if (heatmapRef.current) {
      heatmapRef.current.setMap(null);
    }

    if (showHeatmap && heatmapData.length > 0) {
      const heatmapData_formatted = heatmapData.map(point => ({
        location: new google.maps.LatLng(point.lat, point.lng),
        weight: point.intensity,
      }));

      heatmapRef.current = new google.maps.visualization.HeatmapLayer({
        data: heatmapData_formatted,
        map: mapInstanceRef.current,
        radius: 50,
        opacity: 0.6,
      });
    }
  }, [heatmapData, showHeatmap, isLoaded]);

  // Highlight selected alert
  useEffect(() => {
    if (!selectedAlert || !mapInstanceRef.current) return;
    
    mapInstanceRef.current.setCenter({
      lat: selectedAlert.location.lat,
      lng: selectedAlert.location.lng,
    });
    mapInstanceRef.current.setZoom(15);
  }, [selectedAlert]);

  const createMarker = (alert: Alert, map: google.maps.Map) => {
    const icon = getMarkerIcon(alert.type, alert.severity);
    
    const marker = new google.maps.Marker({
      position: {
        lat: alert.location.lat,
        lng: alert.location.lng,
      },
      map,
      icon,
      title: alert.title,
      animation: alert.severity === 'critical' ? google.maps.Animation.BOUNCE : undefined,
    });

    // Create info window
    const infoWindow = new google.maps.InfoWindow({
      content: createInfoWindowContent(alert),
    });

    marker.addListener('click', () => {
      infoWindow.open(map, marker);
    });

    return marker;
  };

  const getMarkerIcon = (type: Alert['type'], severity: Alert['severity']) => {
    const colors = {
      critical: '#DC2626',
      high: '#EA580C', 
      medium: '#D97706',
      low: '#16A34A',
    };

    const symbols = {
      flood: '💧',
      collapse: '🏢',
      incident: '⚠️',
      fire: '🔥',
      earthquake: '🌍',
    };

    return {
      url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
        <svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
          <circle cx="16" cy="16" r="12" fill="${colors[severity]}" stroke="white" stroke-width="2"/>
          <text x="16" y="20" text-anchor="middle" font-size="12" fill="white">${symbols[type]}</text>
        </svg>
      `)}`,
      scaledSize: new google.maps.Size(32, 32),
      anchor: new google.maps.Point(16, 16),
    };
  };

  const createInfoWindowContent = (alert: Alert) => {
    const timeAgo = getTimeAgo(alert.timestamp);
    const severityColor = {
      critical: 'text-red-600',
      high: 'text-orange-600',
      medium: 'text-yellow-600', 
      low: 'text-green-600',
    }[alert.severity];

    return `
      <div class="p-3 max-w-xs">
        <div class="flex items-center justify-between mb-2">
          <h3 class="font-semibold text-gray-900">${alert.title}</h3>
          <span class="px-2 py-1 text-xs font-medium ${severityColor} bg-opacity-10 rounded-full">
            ${alert.severity.toUpperCase()}
          </span>
        </div>
        <p class="text-sm text-gray-600 mb-2">${alert.description}</p>
        <div class="space-y-1 text-xs text-gray-500">
          <div>📍 ${alert.location.address}</div>
          <div>🏘️ ${alert.location.district}</div>
          <div>⏰ ${timeAgo}</div>
          ${alert.affectedPopulation ? `<div>👥 ${alert.affectedPopulation.toLocaleString()} afectados</div>` : ''}
        </div>
      </div>
    `;
  };

  const getTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Ahora mismo';
    if (diffInMinutes < 60) return `Hace ${diffInMinutes} min`;
    if (diffInMinutes < 1440) return `Hace ${Math.floor(diffInMinutes / 60)} horas`;
    return `Hace ${Math.floor(diffInMinutes / 1440)} días`;
  };

  if (error) {
    return (
      <div className={`bg-red-50 border border-red-200 rounded-lg p-8 text-center ${className}`}>
        <div className="text-red-600 text-lg font-semibold mb-2">Error al cargar el mapa</div>
        <div className="text-red-500 text-sm">{error}</div>
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      <div ref={mapRef} className="w-full h-full rounded-lg" />
      
      {!isLoaded && (
        <div className="absolute inset-0 bg-gray-100 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-500 mx-auto mb-4"></div>
            <div className="text-gray-600">Cargando mapa...</div>
          </div>
        </div>
      )}
      
      {/* Map Controls */}
      {isLoaded && (
        <div className="absolute top-4 right-4 space-y-2">
          <button
            onClick={() => {
              if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition((position) => {
                  dispatch(setCenter({
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                  }));
                  dispatch(setZoom(15));
                });
              }
            }}
            className="bg-white p-2 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-200"
            title="Mi ubicación"
          >
            🎯
          </button>
        </div>
      )}
    </div>
  );
}